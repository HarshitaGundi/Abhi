package cs520.hw5;
import java.util.ArrayList;

/**
 * This class keeps track of name, grades in homeworks as an array list
 * The overwritten toString method prints the name and average of homework scores 
 * which is calculated. 
 */
public class Student {

	//Declaration of instance variables
	private String name;
	private ArrayList<Integer>homework;
	
	//constructor initializing name and homework
	public Student(String name) {	
		homework = new ArrayList<Integer>();
	    this.name = name;
	}

	// This method sets name of the student
	public void setname(String name)
	{
		this.name =  name;
	}
	
	//This method gets student name
	public String getname()
	{
		return name;
	}
	
	//This method adds new homework grade to Student object
	public void addHomeworkGrade(int newgrade)
	{
		this.homework.add(newgrade);	
	}
	
	//This method computes average of student homework grades by looping over the arraylist elements
	public double computeAverage()
	{
		double sum = 0.0,average;
		
		//This loop reads homework grades and calculates average of homework grades
		for(int i = 0;i <homework.size();i++)
		{
			sum = sum + homework.get(i);
		}
		average = sum/homework.size();
		return average;
	}
	
	//String representation of object with student name and average grade(calculated from computeAverage method)
    public String toString()
	{
		return( this.name + "'s average grade is " +  String.format("%.2f",computeAverage())); 
	}
}