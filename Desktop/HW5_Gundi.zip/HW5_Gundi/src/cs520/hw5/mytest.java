package cs520.hw5;

public class mytest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student s1 = new Student("Abhilash");
		s1.addHomeworkGrade(10);
		s1.addHomeworkGrade(20);
		s1.addHomeworkGrade(30);
		System.out.println(s1.toString());

	}

}
