package cs520.hw5;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Set;
import java.util.StringTokenizer;
import cs520.hw5.Student;

/***
 * This class tests functionality of Student class
 * Adds the student objects created after parsing the data.txt file
 * to a queue and a map. At the end, iterates over the queue and map 
 * to print the String representation of Student object
 */
public class test {

   public static void main(String[] args) {
		
		//Declarations
		LinkedList<Student> studentQueue =  new LinkedList<Student>();
		HashMap<String, Student> studentMap  = new HashMap<String, Student>();
		String inputFileName = "data.txt";
		FileReader fileReader = null;

		//creating file reader object
		try{
			fileReader = new FileReader(inputFileName);
		} catch(FileNotFoundException e){    //handling file not found exception
			e.printStackTrace();
		}
		
		//Using BufferedReader class to read the data.txt file		
		BufferedReader reader = new BufferedReader(fileReader);
		String input;
		
		try{
				input = reader.readLine();
			    System.out.println("Input file processing...");
				//  Reading contents of text file line by line using while loop
				while (input!=null)
				{	
					Student mys = processInputData(input); // Calling processInputData on each input line and storing the returned object in mys
					studentQueue.add(mys); 					//Adding student object to student queue
					studentMap.put(mys.getname(),mys);     //Assigning studentMap with key as name and mapping it to student object 
					input = reader.readLine();
				}
				
				System.out.println("\nIterating over the student list...");
				//iterating over student queue and printing to console
				for(int i = 0;i<studentQueue.size();i++)
				{	
					System.out.println(studentQueue.get(i).toString());
				}
		        
				
				Set<String> nameKeys = studentMap.keySet();   // store the keys in the map in nameKeys
				Iterator<String> nameIterator = nameKeys.iterator();  //creating iterator over keys
				System.out.println("\nIterating over the student map...");
				
				//Iterating over each key in this set and display the associated object in the map to the console.
				while(nameIterator.hasNext())
				{
					String n = nameIterator.next();
					System.out.println(studentMap.get(n).toString());
				}
				//handling null pointer exception
			}catch (IOException e){
					e.printStackTrace();
			}
		//closing input file reader
		try{
				fileReader.close();
			}catch (IOException e){
				e.printStackTrace();
			}
	}
   
   private static Student processInputData(String data)
   {
		 StringTokenizer st = new StringTokenizer(data,","); // The string argument is tokenized using StringTokenizer class using comma as delimiter
		 String name = st.nextToken(); 		 //Extracting name token from data
		 Student currentStudent= new Student(name); 		 // creating Student object and assigning it with name 
		 
		  //This loop reads each homework grade token 
		  while(st.hasMoreTokens())
		  {
			  currentStudent.addHomeworkGrade(Integer.parseInt(st.nextToken())); //Adding homework grade to Student object
		  }

		 System.out.println(currentStudent.toString()); 	//Displays the string representation of the currentStudent object to the console.
		return currentStudent;  //return currentStudent which is an object of Student 
	}
}